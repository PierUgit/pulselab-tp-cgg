"""Characterization tests: lock the behaviour of find_pulses before/after a refactoring."""
import glob
import json
import pathlib

import numpy as np
import pytest

from pulselab import config
from pulselab.io import load_run
from pulselab.peaks import find_pulses

HERE = pathlib.Path(__file__).parent
DATA = HERE.parent / "data"


def legacy_find_pulses(x, fs):
    """The original loop implementation, kept as an oracle."""
    thr = config.CONFIG["threshold_v"]
    gap = int(config.CONFIG["min_gap_s"] * fs)
    peaks = []
    last = -10**9
    for i in range(1, len(x) - 1):
        if x[i] > thr and x[i] > x[i - 1] and x[i] >= x[i + 1]:
            if i - last >= gap:
                peaks.append(i)
                last = i
    return np.array(peaks, dtype=int)


def _smooth_zero_mean(run):
    x = run["signal"] - np.mean(run["signal"])
    n = max(3, int(0.008 * run["fs"]))
    return np.convolve(x, np.ones(n) / n, mode="same")


@pytest.fixture(autouse=True)
def quiet():
    config.CONFIG["verbose"] = False


@pytest.mark.parametrize("path", sorted(glob.glob(str(DATA / "*.csv"))))
def test_pulses_match_golden_file(path):
    golden = json.loads((HERE / "golden" / "pulses.json").read_text())
    run = load_run(path)
    got = find_pulses(_smooth_zero_mean(run), run["fs"])
    assert got.tolist() == golden[run["name"]]


@pytest.mark.parametrize("seed", range(20))
@pytest.mark.parametrize("gap_s", [0.0, 0.01, 0.05])
def test_vectorized_equals_legacy_on_random_signals(seed, gap_s):
    rng = np.random.default_rng(seed)
    x = rng.normal(0.0, 0.2, 5000)
    x[rng.integers(0, 5000, 30)] = 1.0          # plateaus / ties are possible
    old = dict(config.CONFIG)
    try:
        config.CONFIG["min_gap_s"] = gap_s
        assert find_pulses(x, 1000.0).tolist() == legacy_find_pulses(x, 1000.0).tolist()
    finally:
        config.CONFIG.update(old)


@pytest.mark.parametrize("n", [0, 1, 2, 3])
def test_tiny_signals(n):
    x = np.ones(n)
    assert find_pulses(x, 1000.0).tolist() == legacy_find_pulses(x, 1000.0).tolist()

"""Regression tests for the two bugs found in the day-1 debugging lab."""
import numpy as np
import pytest

from pulselab import config
from pulselab.io import load_run
from pulselab.preprocess import estimate_noise, remove_offset
from pulselab.report import analyze_run
from pulselab.stats import snr_db


@pytest.fixture(autouse=True)
def quiet():
    config.CONFIG["verbose"] = False


def test_remove_offset_returns_a_copy():
    x = np.array([1.0, 2.0, 3.0])
    y = remove_offset(x)
    assert x.tolist() == [1.0, 2.0, 3.0]          # input untouched
    assert abs(np.mean(y)) < 1e-12


def test_estimate_noise_does_not_modify_its_input():
    x = np.random.default_rng(0).normal(5.0, 0.1, 1000)
    before = x.copy()
    estimate_noise(x)
    assert np.array_equal(x, before)


def test_analyze_run_does_not_modify_the_run():
    run = load_run("data/run01.csv")
    before = run["signal"].copy()
    analyze_run(run)
    assert np.array_equal(run["signal"], before)


def test_reported_offset_is_the_raw_mean_not_zero():
    run = load_run("data/run03.csv")               # true offset 0.60 V
    raw_mean = float(np.mean(run["signal"]))
    row = analyze_run(run)
    assert row["offset_V"] == pytest.approx(raw_mean)
    assert row["offset_V"] == pytest.approx(0.60, abs=0.05)


def test_analyzing_twice_gives_the_same_result():
    run = load_run("data/run02.csv")
    assert analyze_run(run) == analyze_run(run)


def test_snr_is_an_amplitude_ratio_in_db():
    assert snr_db(10.0, 1.0) == pytest.approx(20.0)
    assert snr_db(1.0, 1.0) == pytest.approx(0.0)

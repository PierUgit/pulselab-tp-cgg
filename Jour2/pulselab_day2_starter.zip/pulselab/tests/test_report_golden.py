"""Golden-file test: the summary CSV must not change during a refactoring."""
import pathlib
import subprocess
import sys

import pandas as pd

ROOT = pathlib.Path(__file__).resolve().parents[1]


def test_summary_csv_matches_the_golden_file(tmp_path):
    out = tmp_path / "summary.csv"
    subprocess.run(
        [sys.executable, str(ROOT / "scripts" / "run_analysis.py"), "--data", str(ROOT / "data"), "--out", str(out), "--quiet"],
        check=True, capture_output=True, cwd=ROOT,
    )
    got = pd.read_csv(out)
    expected = pd.read_csv(ROOT / "tests" / "golden" / "summary_expected.csv")
    pd.testing.assert_frame_equal(got, expected, check_exact=False, rtol=1e-6, atol=1e-9)

# pulselab

Small analysis toolkit for noisy pulse-train measurements (offset, noise, SNR,
dominant frequency, pulse count, decay time, optional band power).

## Install

    pip install -r requirements.txt

## Usage

    python scripts/run_analysis.py --data data --out summary.csv
    python scripts/run_analysis.py --data data --out summary.csv --band 1 5

`--band FMIN FMAX` adds a `band_power_V2` column: the signal power (V^2) between
FMIN and FMAX Hz, integrated from a Welch power spectral density.

## Tests

    python -m pytest -q

## Data

Files in `data/` are CSV, with a short `#` header (instrument, calibration in
V per count). Regenerate them with `python scripts/make_data.py`.

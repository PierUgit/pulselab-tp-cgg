"""Analyse all runs of a folder and write a summary CSV.

python scripts/run_analysis.py --data data --out summary.csv [--band FMIN FMAX]
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from pulselab import config
from pulselab.report import analyze_folder, print_table, write_summary


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data")
    ap.add_argument("--out", default="summary.csv")
    ap.add_argument("--threshold", type=float, default=None, help="pulse threshold [V]")
    ap.add_argument("--band", type=float, nargs=2, metavar=("FMIN", "FMAX"), default=None,
                    help="also report the signal power in [FMIN, FMAX] Hz")
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()

    if args.threshold is not None:
        config.CONFIG["threshold_v"] = args.threshold
    if args.band is not None:
        config.CONFIG["band"] = tuple(args.band)
    if args.quiet:
        config.CONFIG["verbose"] = False

    rows = analyze_folder(args.data)
    print_table(rows)
    write_summary(rows, args.out)


if __name__ == "__main__":
    main()

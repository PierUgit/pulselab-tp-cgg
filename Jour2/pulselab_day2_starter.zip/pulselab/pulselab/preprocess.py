import numpy as np


def remove_offset(x):
    """Return a copy of x with its mean removed (x itself is left untouched)."""
    x = np.asarray(x, dtype=float)
    return x - np.mean(x)


def moving_average(x, n):
    return np.convolve(x, np.ones(n) / n, mode="same")


def estimate_noise(x):
    """White-noise sigma estimated from the first differences."""
    x = remove_offset(x)
    return float(np.std(np.diff(x)) / np.sqrt(2))

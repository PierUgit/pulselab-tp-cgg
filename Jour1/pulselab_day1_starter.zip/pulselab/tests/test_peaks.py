import numpy as np

from pulselab.peaks import find_pulses


def test_find_three_pulses():
    x = np.zeros(1000)
    x[[100, 400, 700]] = 1.0
    assert len(find_pulses(x, 1000.0)) == 3

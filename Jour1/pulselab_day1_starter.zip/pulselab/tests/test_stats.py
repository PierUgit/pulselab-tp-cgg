import numpy as np

from pulselab.stats import rms


def test_rms_runs():
    assert rms(np.ones(10)) > 0

import numpy as np
from scipy.optimize import curve_fit


def _model(t, a, tau):
    return a * np.exp(-t / tau)


def fit_decay(t_peaks, heights):
    """Decay time tau [s] of the pulse amplitudes."""
    try:
        p0 = (heights[0], (t_peaks[-1] - t_peaks[0]) or 1.0)
        popt, pcov = curve_fit(_model, t_peaks, heights, p0=p0)
        return float(popt[1])
    except:
        return float("nan")

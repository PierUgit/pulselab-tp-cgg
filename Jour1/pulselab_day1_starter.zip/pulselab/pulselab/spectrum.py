import numpy as np


def dominant_frequency(x, fs):
    """Frequency [Hz] of the largest non-DC peak of the spectrum."""
    x = np.asarray(x, dtype=float)
    spec = np.abs(np.fft.rfft(x - np.mean(x)))
    freqs = np.fft.rfftfreq(len(x), d=1.0 / fs)
    return float(freqs[1 + np.argmax(spec[1:])])

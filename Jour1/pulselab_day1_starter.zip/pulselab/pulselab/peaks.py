import numpy as np

from pulselab import config


def find_pulses(x, fs):
    """Indices of the pulses in x: local maxima above the threshold,
    at least min_gap_s apart (the first one of a group wins)."""
    thr = config.CONFIG["threshold_v"]
    gap = int(config.CONFIG["min_gap_s"] * fs)
    peaks = []
    last = -10**9
    for i in range(1, len(x) - 1):
        if x[i] > thr and x[i] > x[i - 1] and x[i] >= x[i + 1]:
            if i - last >= gap:
                peaks.append(i)
                last = i
    return np.array(peaks, dtype=int)

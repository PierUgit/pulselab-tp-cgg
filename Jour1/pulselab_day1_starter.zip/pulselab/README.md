# pulselab

Small analysis toolkit for noisy pulse-train measurements (offset, noise, SNR,
dominant frequency, pulse count, decay time).

## Usage

    python run_analysis.py --data data --out summary.csv

## Data

Files in `data/` are CSV, with a short `#` header (instrument, calibration).
